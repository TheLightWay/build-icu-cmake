// Copyright (C) 2016 and later: Unicode, Inc. and others.
// License & terms of use: http://www.unicode.org/copyright.html
//*******************************************************************************
//*
//*   Copyright (C) 1998-2000, International Business Machines
//*   Corporation and others.  All Rights Reserved.
//*
//*******************************************************************************

This directory contains data files used to test International Collectanea for Unicode.
